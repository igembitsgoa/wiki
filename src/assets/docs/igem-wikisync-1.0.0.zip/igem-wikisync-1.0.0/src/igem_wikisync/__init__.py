__version__ = '1.0.0'
from .wikisync import run

__all__ = ['run']
