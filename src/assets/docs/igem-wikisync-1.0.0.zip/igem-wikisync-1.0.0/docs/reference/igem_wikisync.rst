igem_wikisync
=============

.. testsetup::

    from igem_wikisync import *

.. automodule:: igem_wikisync.wikisync
    :members:
