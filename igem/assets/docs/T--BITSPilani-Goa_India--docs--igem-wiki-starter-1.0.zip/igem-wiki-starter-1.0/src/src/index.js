import "./css/index.scss";
import "./js/main";