.. _usage:

===========
Usage Guide
===========

We've split the  Usage Guide into distinct segments according to the organization of a typical iGEM team. 

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents

   project_structure
   contents
   theme
   functionality
